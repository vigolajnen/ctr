$('[data-fancybox="gallery"]').fancybox({
  // Options will go here
});
