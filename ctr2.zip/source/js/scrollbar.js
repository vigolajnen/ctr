// $(function () {
//   $('.scrollbar').jScrollPane();
// });

jQuery(document).ready(function() {
  jQuery(".scrollbar-inner").scrollbar();
});
