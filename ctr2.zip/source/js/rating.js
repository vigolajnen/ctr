// (function() {
//   var container = document.querySelector(".rating");
//   var items = container.querySelectorAll(".rating__item");
//   if (items) {
//     container.onclick = function(e) {
//       if (!e.target.classList.contains("rating__item--active")) {
//         items.forEach(function(item) {
//           item.classList.remove("rating__item--active");
//         });
//         e.target.classList.add("rating__item--active");
//       }
//     };
//   }
// })();
